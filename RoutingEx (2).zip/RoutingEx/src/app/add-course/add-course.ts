import { Component } from '@angular/core';

@Component({
  selector: 'app-add-course',
  imports: [],
  templateUrl: './add-course.html',
  styleUrl: './add-course.css',
})
export class AddCourse {

}
